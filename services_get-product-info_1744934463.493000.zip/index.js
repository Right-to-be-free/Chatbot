const functions = require('@google-cloud/functions-framework');

// Product database
const products = {
  "nitrile exam gloves": {
    id: "P001",
    type: "PPE - Gloves",
    manufacturer: "MedGlove Inc.",
    expiry: "2026-12-31",
    stock: 5000,
    price: 0.12,
  },
  "surgical face masks": {
    id: "P002",
    type: "PPE - Masks",
    manufacturer: "SafeMed Supplies",
    expiry: "2025-08-15",
    stock: 10000,
    price: 0.25,
  },
  "alcohol prep pads": {
    id: "P003",
    type: "Disinfectant Wipes",
    manufacturer: "CleanSure Health",
    expiry: "2027-03-01",
    stock: 8500,
    price: 0.05,
  },
  "digital thermometer": {
    id: "P004",
    type: "Diagnostic Equipment",
    manufacturer: "HealthTech Devices",
    expiry: "N/A",
    stock: 500,
    price: 14.99,
  },
  "sterile syringes (5ml)": {
    id: "P005",
    type: "Injection Supplies",
    manufacturer: "MedEquip Solutions",
    expiry: "2028-01-20",
    stock: 2200,
    price: 0.40,
  },
};

// HTTP Handler
functions.http('helloHttp', (req, res) => {
  const tag = req.body.fulfillmentInfo.tag;
  const sessionParams = req.body.sessionInfo.parameters || {};
  const rawProductName = sessionParams.product_name;

  const productKey = rawProductName?.toLowerCase();
  const product = products[productKey];

  if (!product) {
    return res.json({ fulfillment_response: { messages: [{ text: { text: [`Sorry, I couldn't find "${rawProductName}" in the inventory.`] } }] } });
  }

  let message = '';

  switch (tag) {
    case 'get_stock':
      message = `We currently have ${product.stock.toLocaleString()} units of ${rawProductName} in stock.`;
      break;
    case 'get_price':
      message = `${rawProductName} costs $${product.price.toFixed(2)} per unit.`;
      break;
    case 'get_expiry':
      message = product.expiry === "N/A"
        ? `${rawProductName} does not have an expiry date.`
        : `The expiry date of ${rawProductName} is ${product.expiry}.`;
      break;
    case 'get_manufacturer':
      message = `${rawProductName} is manufactured by ${product.manufacturer}.`;
      break;
    default:
      message = `Here are the details for ${rawProductName}:\n- Type: ${product.type}\n- Manufacturer: ${product.manufacturer}\n- Stock: ${product.stock}\n- Price: $${product.price}\n- Expiry Date: ${product.expiry}`;
  }

  res.json({
    fulfillment_response: {
      messages: [
        {
          text: {
            text: [message],
          },
        },
      ],
    },
  });
});
